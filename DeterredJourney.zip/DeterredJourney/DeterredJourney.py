"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>

Version.7
Creator: Hamzah Ahmed

Deterred Journey
The objective is to journey from current city to a different city in the allotted time
A game where player’s character is meant to run across the landscape and avoid obstacles placed on the terrain

Completed:
The avatar was added onto the background and the game started
Title Screen Added
Player can successfully jump using the up key
Coins for score
Lives
Obstacles
Updates:
Game over screen has been created
Multiple obstacles have been added
Time has been implemented in game
System for randomly picking an obstacle among obstacle choices
System for adding obstacles to screen after a certain time
Obstacles and coins are now continuously uploaded at random on screen
Time has been added to display
Victory screen has been added for travelling for 5 minutes
Scoreboard has been added with saving score
Audio has been added



"""

import pygame, sys, time, random, threading
from pygame.locals import *

class Background(pygame.sprite.Sprite): #Creates space background
    def __init__(self, image_file, location):
        pygame.sprite.Sprite.__init__(self)  #call Sprite initializer
        self.bgimage = pygame.image.load(image_file).convert()
        self.bgimage = pygame.transform.scale(self.bgimage, (1200, 600))
        self.rectBGimg = self.bgimage.get_rect()

        self.bgY1 = 0
        self.bgX1 = 0

        self.bgY2 = 0
        self.bgX2 = self.rectBGimg.width

        self.movingUpSpeed = 18

    def update(self):
        self.bgX1 -= self.movingUpSpeed
        self.bgX2 -= self.movingUpSpeed
        if self.bgX1 <= -self.rectBGimg.width:
            self.bgX1 = self.rectBGimg.width
        if self.bgX2 <= -self.rectBGimg.width:
            self.bgX2 = self.rectBGimg.width

    def render(self):
        screen.blit(self.bgimage, (self.bgX1, self.bgY1))
        screen.blit(self.bgimage, (self.bgX2, self.bgY2))

class Entity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # This makes a rectangle around the entity, used for anything
        # from collision to moving around.
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

class Duck(Entity):
    """
    Player controlled, main interaction with
    the game
    """

    def __init__(self, x, y, width, height):
        super(Duck, self).__init__(x, y, width, height)
        self.image = duck

class Player(Duck):
    """The player controlled Duck"""


    def __init__(self, x, y, width, height):
        super(Player, self).__init__(x, y, width, height)

        # How many pixels the Player duck should move on a given frame.
        self.y_change = 0
        # How many pixels the spaceship should move each frame a key is pressed.
        self.x_change = 0

        # Positive = down, negative = up
        self.y_direction = -1
        # Current speed.
        self.speed = 13

    def MoveKeyDown(self, key):
        """Responds to a key-down event and moves accordingly."""
        if key in (pygame.K_UP, pygame.K_SPACE):
            self.y_change = -self.speed

    def update(self):
        self.rect.move_ip(self.x_change, self.y_change)


class Branch(Entity):
    """
        Moves with the screen
        """

    def __init__(self, x, y, width, height):
        super(Branch, self).__init__(x, y, width, height)

        self.image = branchpic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5
    def soundeffect(self):
        slip.play()

    def update(self):
        self.rect.x-= 12

class Bush(Entity):
    """
        Moves with the screen
        """

    def __init__(self, x, y, width, height):
        super(Bush, self).__init__(x, y, width, height)

        self.image = bushpic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5
    def soundeffect(self):
        rustle.play()
    def update(self):
        self.rect.x-= 12

class Sign(Entity):
    """
        Moves with the screen
        """

    def __init__(self, x, y, width, height):
        super(Sign, self).__init__(x, y, width, height)

        self.image = signpic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5
    def soundeffect(self):
        whack.play()

    def update(self):
        self.rect.x-= 12

class Snake(Entity):
    """
        Moves with the screen
        """

    def __init__(self, x, y, width, height):
        super(Snake, self).__init__(x, y, width, height)

        self.image = snakepic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5
    def soundeffect(self):
        rattling.play()
    def update(self):
        self.rect.x-= 12

class Bird(Entity):
    """
        Moves with the screen
        """

    def __init__(self, x, y, width, height):
        super(Bird, self).__init__(x, y, width, height)

        self.image = birdpic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5
    def soundeffect(self):
        dove.play()

    def update(self):
        self.rect.x-= 12

class Coin(Entity):
    """
            Moves with the screen
            """

    def __init__(self, x, y, width, height):
        super(Coin, self).__init__(x, y, width, height)

        self.image = coinpic

        # Positive = down, negative = up
        self.y_direction = 3
        # # Current speed.
        self.speed = 5

    def soundeffect(self):
        ting.play()

    def update(self):
        self.rect.x -= 8

def loadscores():
    global scorelist
    try:
        myfile = open("highscores.txt", "r")
        lines = myfile.readlines()
        scorelist = [item.strip("\n") for item in lines]
    except FileNotFoundError:
        with open('highscores.txt', 'w') as myfile:
            for i in range(10):
                myfile.write("0" + "\n")


def savescore():
    global scorelist
    loadscores()
    with open('highscores.txt', 'w') as myfile:
        scorelist.append(score)
        scorelist = [int(i) for i in scorelist]
        scorelist.sort()
        scorelist.reverse()
        scorelist = [str(i) for i in scorelist]
        for i in scorelist:
            myfile.write(str(i) + "\n")

class SecondCounter(threading.Thread):
    '''
    create a thread object that will do the counting in the background
    default interval is 1/1000 of a second
    '''
    def __init__(self, interval=0.01):
        # init the thread
        threading.Thread.__init__(self)
        self.interval = interval  # seconds
        # initial value
        self.value = 0
        self.minutes = 0
        # controls the while loop in method run
        self.alive = False
    def run(self):
        '''
        this will run in its own thread via self.start()
        '''
        self.alive = True
        while self.alive:
            time.sleep(self.interval)
            # update count value
            self.value += self.interval

    def minutesPassed(self):
        if ((round(self.value))) % 60 == 0:
            self.minutes = ((round(self.value))/60)
        return self.minutes

    def secondsPassed(self):
        '''
        close the thread, return final value
        '''
        # stop the while loop in method run
        if self.value == 60:
            self.value = 0
        return self.value


def scoreRecorder(all): #Checks if laser hit an asteroid and removes laser and asteroid while adding score and explosion sound
    global score, coinlist
    for i in all:
        if i.rect.colliderect(player.rect):
            coinlist = pygame.sprite.Group()
            score+=100
            ting.play()

def checkHit(all): #Checks if laser hit an asteroid and removes laser and asteroid while adding score and explosion sound
    global score, lives, obstaclelist
    for i in all:
        if i.rect.colliderect(player.rect):
            obstaclelist = pygame.sprite.Group()
            score-=100
            lives -= 1

def obstacleCheck(all):
    global obstaclelist
    for i in all:
        if i.rect.x<-100:
            obstaclelist = pygame.sprite.Group()
pygame.init()

FPS = 15  # frames per second setting
clock = pygame.time.Clock()

window_width = 1200
window_height = 600

# set up the window
screen = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Deterred Journey')

BackGround = Background('scrollingBackground.png', [0,0])
duck = pygame.image.load('walkingduck.png')
branchpic = pygame.image.load('branch.png')
coinpic = pygame.image.load('coin.png')
bushpic = pygame.image.load("bush.png")
birdpic = pygame.image.load("predator.png")
snakepic = pygame.image.load("snake.png")
signpic = pygame.image.load("sign.png")

GRAVITY = .9
player = Player(0, 650, 120, 160) #Making player object(duck)
clock = pygame.time.Clock()
move = False
running = True

all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(player)
obstaclelist = pygame.sprite.Group()
branch = Branch(2000, 570, 100, 23)
bush = Bush(2000, 500, 200, 95)
bird = Bird(2000, 220, 160, 100)
snake = Snake(2000, 500, 120, 93)
sign = Sign(2000, 500, 120, 113)
coin = Coin(1200, 520, 70, 70)
coinlist = pygame.sprite.Group()
coinlist.add(coin)

obstacles = [bird, bush, branch, snake, sign]
obstacle = None

music = pygame.mixer.music.load('backgroundmsc.mp3')
pygame.mixer.music.play(-1, 0.0)
ting =  pygame.mixer.Sound('ting.wav')
rattling =  pygame.mixer.Sound('rattling.wav')
dove =  pygame.mixer.Sound('dove.wav')
whack =  pygame.mixer.Sound('whack.wav')
slip =  pygame.mixer.Sound('slip.wav')
rustle =  pygame.mixer.Sound('rustle.wav')
victorysound =  pygame.mixer.Sound('victory.wav')
defeat = pygame.mixer.Sound('defeat.wav')
# create the class instance
count = SecondCounter()
# start the count for seconds passed
count.start()

score = 0
lives = 3
intro=True
fontObj = pygame.font.Font('freesansbold.ttf', 50)
fontObj2 = pygame.font.Font('freesansbold.ttf', 28)
title = fontObj.render("Deterred Journey", True,(255,255,255))
start = fontObj.render("Start", True,(255,255,255))
quit = fontObj.render("Quit", True,(255,255,255))
scoretext = fontObj.render("Score:" + str(score), True,(255,255,255))
livestext = fontObj.render("Lives:" + str(lives), True,(255,255,255))
gameover = fontObj.render("Game Over!", True,(255,255,255))
victory = fontObj.render("You have reached your destination!", True,(255,255,255))
seconds = fontObj.render("Seconds: " + str(round(count.secondsPassed())), True,(255,255,255))
minutes = fontObj.render("Minutes: " + str(round(count.minutesPassed())), True,(255,255,255))
instructions = fontObj2.render("Use the up key or space bar to jump and avoid obstacles. Survive for 3 minutes to win.", True,(255,255,255))
newgame = fontObj.render("New Game", True,(255,255,255))

score = 0
scorelist = []

loadscores()
#Scores
textSurfaceObj4 = fontObj.render("High Scores", True,(255,255,255))
score1 = fontObj.render(scorelist[0], True,(255,255,255))
score2 = fontObj.render(scorelist[1], True,(255,255,255))
score3 = fontObj.render(scorelist[2], True,(255,255,255))
score4 = fontObj.render(scorelist[3], True,(255,255,255))
score5 = fontObj.render(scorelist[4], True,(255,255,255))
score6 = fontObj.render(scorelist[5], True,(255,255,255))
score7 = fontObj.render(scorelist[6], True,(255,255,255))
score8 = fontObj.render(scorelist[7], True,(255,255,255))
score9 = fontObj.render(scorelist[8], True,(255,255,255))
score10 = fontObj.render(scorelist[9], True,(255,255,255))

def introduction():
    global start, intro, title, start, quit, instructions
    while intro:  # Equivalent to into == True
        screen.fill((105, 105, 105))
        screen.blit(title, ((window_width / 2) - 200, 80))
        screen.blit(start, ((window_width / 2) - 100, 240))
        screen.blit(quit, ((window_width / 2) - 100, 380))
        screen.blit(instructions, (10, 530))

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            # got rid of another if statement
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if start.get_rect(x=(window_width / 2) - 100, y=240).collidepoint(x, y):  # changed start.get_rect
                    start = fontObj.render("Start", True, (255, 255, 255))
                    intro = False
                if quit.get_rect(x=(window_width / 2) - 100, y=380).collidepoint(x, y):  # changed start.get_rect
                    start = fontObj.render("Quit", True, (255, 255, 255))
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)
    rungame()

def rungame():
    global running, scoretext, livestext, seconds, minutes, coinlist, obstaclelist, move, victorysound, defeat, bush, branch, bird, snake, sign, coin, obstacles, count
    while running:

        if lives == 0:
            running = False
        if count.secondsPassed() >= 180:
            running = False

        BackGround.render()
        screen.blit(scoretext, (0, 0))
        screen.blit(livestext, (350, 0))
        screen.blit(seconds, (600, 0))
        screen.blit(minutes, (920, 0))
        scoreRecorder(coinlist)
        checkHit(obstaclelist)
        obstacleCheck(obstaclelist)

        if int(round(count.secondsPassed())) % 5 == 0 and len(obstaclelist) == 0:
            obstaclelist = pygame.sprite.Group()
            branch = Branch(2000, 565, 80, 23)
            bush = Bush(2000, 520, 120, 85)
            bird = Bird(2000, 220, 120, 100)
            snake = Snake(2000, 520, 80, 78)
            sign = Sign(2000, 515, 80, 94)
            coin = Coin(1200, 520, 70, 70)
            coinlist = pygame.sprite.Group()
            coinlist.add(coin)
            obstacles = [bird, bush, branch, snake, sign]

            obstaclelist.add(random.choice(obstacles))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_SPACE):
                    move = True
            if event.type == pygame.KEYUP:
                if event.key in (pygame.K_UP, pygame.K_SPACE):
                    move = False

        if move and player.rect.bottom >= 650:  # Fly upwards.
            player.y_change = -15
            for ent in all_sprites_list:
                ent.update()
            all_sprites_list.update()
        else:  # Add the gravity to the y-velocity.
            player.y_change += GRAVITY
        player.rect.move_ip(0, player.y_change)

        for ent in all_sprites_list:
            ent.update()
        all_sprites_list.update()
        for ent in obstaclelist:
            ent.update()
        obstaclelist.update()
        for ent in coinlist:
            ent.update()
        coinlist.update()

        # Clamp the rect.y value to the range 50 to 450-rect.h.
        # You could also use rect.clamp_ip((0, 50, 800, 450)).
        if player.rect.y < 220:
            player.rect.y = 220
            player.y_change = 0
        elif player.rect.bottom >= 650:
            player.rect.bottom = 650
            player.y_change = 0

        # Adds images and text

        scoretext = fontObj.render("Score: " + str(score), True, (255, 255, 255))
        livestext = fontObj.render("Lives: " + str(lives), True, (255, 255, 255))
        seconds = fontObj.render("Seconds: " + str(round(count.secondsPassed())), True, (255, 255, 255))
        minutes = fontObj.render("Minutes: " + str(round(count.minutesPassed())), True, (255, 255, 255))
        BackGround.update()

        all_sprites_list.draw(screen)
        obstaclelist.draw(screen)
        coinlist.draw(screen)

        pygame.display.flip()
        pygame.display.update()
        clock.tick(30)

    if lives == 0:
        defeat.play()
        gamelost()
    if count.secondsPassed() >= 180:
        victorysound.play()
        wingame()
def gamelost():
    global start, lives, newgame, gameover, title, window_width, running, quit

    while lives == 0:
        screen.fill((105, 105, 105))
        screen.blit(title, ((window_width / 2) - 200, 80))
        screen.blit(gameover, ((window_width / 2) - 150, 300))
        screen.blit(newgame, ((window_width / 2) - 150, 400))
        screen.blit(quit, ((window_width / 2) - 100, 500))

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            # got rid of another if statement
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos

                if newgame.get_rect(x=(window_width / 2) - 150, y=400).collidepoint(x, y):  # changed start.get_rect
                    newgame = fontObj.render("New Game", True, (255, 255, 255))
                    lives = 3
                    running=True
                    rungame()

                if quit.get_rect(x=(window_width / 2) - 100, y=500).collidepoint(x, y):  # changed start.get_rect
                    quit = fontObj.render("Quit", True, (255, 255, 255))
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)
def wingame():
    global start, title, quit, victory, count, score1, score2, score3, score4, score5, score6, score7, score8, score9, score10

    while count.secondsPassed() >= 180:
        screen.fill((105, 105, 105))
        screen.blit(title, ((window_width / 2) - 200, 80))
        screen.blit(quit, ((window_width / 2) - 100, 480))
        screen.blit(victory, ((window_width / 2) - 420, 550))

        savescore()

        screen.blit(score1, ((window_width / 2) - 300, 180))
        screen.blit(score2, ((window_width / 2) - 300, 230))
        screen.blit(score3, ((window_width / 2) - 300, 280))
        screen.blit(score4, ((window_width / 2) - 300, 330))
        screen.blit(score5, ((window_width / 2) - 300, 380))
        screen.blit(score6, ((window_width / 2) + 200, 180))
        screen.blit(score7, ((window_width / 2) + 200, 230))
        screen.blit(score8, ((window_width / 2) + 200, 280))
        screen.blit(score9, ((window_width / 2) + 200, 330))
        screen.blit(score10, ((window_width / 2) + 200, 380))
        score1 = fontObj.render(scorelist[0], True, (255, 255, 255))
        score2 = fontObj.render(scorelist[1], True, (255, 255, 255))
        score3 = fontObj.render(scorelist[2], True, (255, 255, 255))
        score4 = fontObj.render(scorelist[3], True, (255, 255, 255))
        score5 = fontObj.render(scorelist[4], True, (255, 255, 255))
        score6 = fontObj.render(scorelist[5], True, (255, 255, 255))
        score7 = fontObj.render(scorelist[6], True, (255, 255, 255))
        score8 = fontObj.render(scorelist[7], True, (255, 255, 255))
        score9 = fontObj.render(scorelist[8], True, (255, 255, 255))
        score10 = fontObj.render(scorelist[9], True, (255, 255, 255))

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            # got rid of another if statement
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos

                if quit.get_rect(x=(window_width / 2) - 100, y=480).collidepoint(x, y):  # changed start.get_rect
                    start = fontObj.render("Quit", True, (255, 255, 255))
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)
introduction()